package br.livro.android.cap17.webservice;

import java.io.IOException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class ExemploRestActivity extends Activity implements OnClickListener, Runnable {
	private static final String CATEGORIA = "livro";
	private Handler handler = new Handler();
	private ProgressDialog dialog;

	// URL do Servlet. IP 10.0.2.2 � para o localhost

	private static final String HOST = "projetowagnerfusca.herokuapp.com";
	private static final String PATH = "/rest/primeiro/exemploandroid/";	
	
	@Override
	public void onCreate(Bundle bundle) {
		super.onCreate(bundle);
		setContentView(R.layout.chamada_rest);
		Button b = (Button) findViewById(R.id.btnEnviar);
		b.setOnClickListener(this);
	}

	public void onClick(View view) {
		dialog = ProgressDialog.show(this, "Exemplo", "esperando web service, por favor aguarde...", false, true);
		// Faz a soma em outra Thread
		new Thread(this).start();
	}

	public void run() {
		EditText textoDigitado = (EditText) findViewById(R.id.valor_1);
		final TextView textExibir = (TextView) findViewById(R.id.resultado);

		String novoPath = PATH + textoDigitado.getText().toString();
	
		try {
			final String resultado = converse(HOST, 80, novoPath);
			handler.post(new Runnable() {
				public void run() {
					textExibir.setText("Resultado: " + resultado);
					Log.i(CATEGORIA, String.valueOf(resultado));
					textExibir.setVisibility(View.VISIBLE);
				}
			});
		} catch (Exception e) {
			Log.e(CATEGORIA, e.getMessage(), e);
		} finally {
			dialog.dismiss();
		}
	}
	public static String converse(String host, int port, String path) throws IOException{
		HttpHost target = new HttpHost(host, port);
		HttpClient client = new DefaultHttpClient();
		HttpGet get = new HttpGet(path);
		HttpEntity results = null;
		
		try{
			HttpResponse response = client.execute(target, get);
			results = response.getEntity();
			return EntityUtils.toString(results);
		} catch (Exception e){
			throw new RuntimeException("Nao encontrou o webservice");
		} finally{
			if (results != null){
				try{
					results.consumeContent();
				} catch(IOException e){
					
				}
			}
		}

	}
}